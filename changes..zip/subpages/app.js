let VideoCutscene = document.getElementById("VideoCutscene");




VideoCutscene.play();