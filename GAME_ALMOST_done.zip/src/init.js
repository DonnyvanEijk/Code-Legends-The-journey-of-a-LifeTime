(function () {
//check if work
  const overworld = new Overworld({
    element: document.querySelector(".game-container")
  });
  overworld.init();

})();