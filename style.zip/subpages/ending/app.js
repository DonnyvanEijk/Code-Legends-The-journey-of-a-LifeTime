let music = new Audio('/music/future_or_present_music (1).mp3');
music.play();  

music.volume = "0.2"

let ending = document.getElementById("ending")


ending.style.opacity = "1"